package com.fluidframes.enn

import java.nio.ByteBuffer

/**
 * Hợp đồng mô hình flow (xem models/README.md):
 *  - input : float32 NCHW [1,6,H,W]
 *  - output: float32 NCHW [1,5,H/2,W/2]
 */
interface InferenceBackend {
    /** Tên ngắn trên HUD, ví dụ "NPU ultra/INT8". */
    val name: String

    /** true nếu thực sự chạy trên NPU. */
    val onNpu: Boolean

    /** Đường asset đã nạp, ví dụ models/flow_640_ultra_int8.tflite — rỗng nếu chưa nạp. */
    val modelPath: String get() = ""

    /** Profile suy ra từ tên file: nano|ultra|lite|full|unknown */
    val modelProfile: String get() = "unknown"

    fun load(longSide: Int, procW: Int, procH: Int): Boolean

    fun run(input: ByteBuffer, output: ByteBuffer): Float

    fun close()
}
