# Xclipse ENN-SS – ghi chú triển khai tối ưu 2.0

## 1. Những gì đã thay đổi

### Governor thích ứng có công tắc riêng

Các file:
- `core-telemetry/src/main/java/com/fluidframes/telemetry/Governor.kt`
- `core-overlay/src/main/java/com/fluidframes/overlay/FluidSettings.kt`
- `core-overlay/src/main/java/com/fluidframes/overlay/MenuOverlay.kt`
- `app/src/main/java/com/fluidframes/app/FramePipeline.kt`
- `app/src/main/java/com/fluidframes/app/ui/SettingsScreen.kt`

`FluidSettings.governorEnabled` được lưu bằng SharedPreferences với key `governor_enabled`, mặc định bật cho bản cài mới. Menu nổi có dòng **Governor thích ứng** ngay dưới công tắc nội suy tổng. Có thêm công tắc tương ứng trong màn Cài đặt.

Khi bật:
- Tính ngân sách xử lý gần đúng theo `500 / sourceFps` ms cho mỗi lần tạo frame trung gian.
- Hạ một bậc tier nếu thời gian xử lý vượt 82% ngân sách hoặc drop rate từ 6% trở lên.
- Hạ mạnh hơn nếu vượt ngân sách hoặc drop rate từ 12% trở lên.
- Thermal status SEVERE trở lên sẽ ép hạ tier.
- Chỉ thử tăng một bậc sau 180 quyết định ổn định, nhiệt ở mức NORMAL/LIGHT, work dưới 55% ngân sách và drop dưới 1%.
- Hysteresis giúp tránh đổi tier qua lại liên tục khi tải dao động quanh ngưỡng.

Khi tắt:
- Không tự hạ/tăng tier theo tải; dùng đúng tier đã chọn. `AUTO` được ánh xạ về 540p như trước.
- Chốt an toàn nhiệt CRITICAL vẫn buộc passthrough. Toggle không vô hiệu hóa bảo vệ phần cứng.

Giới hạn: Governor hiện dùng telemetry pipeline có sẵn (work time, drop rate, Android thermal status). Nó chưa đọc GPU/NPU utilization, memory bandwidth hay power rail từ API riêng của Samsung/Exynos. Không giả lập các số liệu phần cứng chưa có.

### Tối ưu Block Matching shader

File: `core-vulkan/src/main/shaders/blockmatch.comp`

Vòng tìm kiếm rộng hiện dùng SAD 4x4 mẫu để xếp hạng ứng viên chuyển động. Sau khi chọn ứng viên tốt nhất, shader tính lại bằng SAD 8x8 và thực hiện các vòng tinh chỉnh cục bộ bằng SAD đầy đủ. Mục tiêu là giảm chi phí ở giai đoạn tìm kiếm rộng nhưng vẫn giữ bước tinh chỉnh chất lượng cao.

Đây là thay đổi thuật toán cần benchmark hình ảnh thực tế; không khẳng định chất lượng/hiệu năng tăng trên mọi nội dung. Nếu cảnh có texture nhỏ hoặc aliasing, cần so sánh flow sai số với shader cũ.

## 2. Cách sử dụng toggle Governor

1. Bắt đầu Xclipse ENN-SS như bình thường.
2. Chạm bong bóng nổi để mở menu.
3. Bật/tắt **Governor thích ứng**.
4. Khi tắt, chọn tier 720p/540p/360p để cố định mức xử lý.
5. Khi bật lại, Governor bắt đầu điều chỉnh từ tier được chọn.

Công tắc nội suy tổng và công tắc Governor là hai chức năng riêng: tắt Governor không tắt nội suy.

## 3. Những gì chưa được triển khai trong bản này

- Không thêm model optical-flow AI giả hoặc trọng số ngẫu nhiên. Backend NPU hiện vẫn cần model đã huấn luyện và adapter ENN SDK thực tế.
- Không tuyên bố zero-copy AHardwareBuffer → ENN; cần xác nhận API import và đồng bộ bộ nhớ từ SDK/driver Exynos cụ thể.
- Không tạo async compute queue độc lập vì pipeline Vulkan hiện tại chỉ chọn một queue family graphics+compute và chưa có kiến trúc semaphore/ownership transfer hoàn chỉnh cho nhiều queue.
- Không thay toàn bộ optical flow bằng dense flow mới vì cần thay đổi descriptor, image pyramid resources, dispatch orchestration và benchmark riêng.
- Không thể xác nhận 7 TFLOPS, 32K MAC hay RDNA 4 chỉ từ tên chip; thông số đó cần tài liệu phần cứng/driver chính thức.

## 4. Kiểm thử

- `Governor.kt` và `Types.kt` đã được biên dịch độc lập bằng Kotlin compiler.
- Chưa thể chạy Android Gradle build trong môi trường chỉnh sửa này: ZIP không kèm Gradle wrapper JAR và môi trường không có lệnh Gradle/Android SDK đầy đủ.
- Shader chưa được biên dịch bằng `glslangValidator` vì công cụ này không có sẵn.
- Cần chạy `./gradlew assembleDebug` trong Android Studio/CI đã cài đúng Android SDK, NDK và CMake; sau đó benchmark trên thiết bị thật.
