# Changelog – optimization pass 2.0

- Added persisted `governorEnabled` setting (default ON for new installs).
- Added **Governor thích ứng** toggle and explanatory state text to the floating overlay menu.
- Added the same switch to the in-app Settings screen.
- Wired the setting into `FramePipeline` and implemented load/drop/thermal-aware tier adaptation with hysteresis.
- Disabling the governor locks the selected processing tier; CRITICAL thermal passthrough remains mandatory.
- Reduced broad-search block-matching cost using coarse 4x4 SAD followed by full 8x8 local refinement.
- Added implementation notes and a small Kotlin smoke test.


## Telemetry correction (benchmark follow-up)
- `drop_pct` now represents processing decisions skipped / frames consumed, not current ring backlog.
- `capture_gap_frames` and `ring_evicted_frames` separately expose intentional latest-frame capture loss.
- NPU stage timing is zeroed outside FLOW_NN so old EMA values are not misattributed to GPU frames.
- ImageReader uses `acquireLatestImage()` to avoid spending compute on stale queued captures.
- Governor pressure thresholds were raised to avoid reacting to small skip-rate noise; processing-time and thermal guards remain active.
