# Xclipse ENN-SS 2.1 – benchmark follow-up patch

## Applied changes

1. **Corrected processing drop-rate semantics**
   - `drop_pct` now means `framesSkipped / framesIn`.
   - It no longer uses `pushed - framesIn`, which was a queue/backlog estimate rather than a dropped-frame counter.
   - Capture-side loss is reported separately through `capture_gap_frames`, `capture_gap_pct`, `ring_evicted_frames`, and `ring_evicted_pct`.

2. **Reduced stale capture work**
   - `ScreenCaptureEngine` now uses `ImageReader.acquireLatestImage()` so the pipeline favors the newest available frame instead of draining an old queue.
   - `FramePipeline` records sequence gaps separately from interpolation failures.

3. **Prevented stale NPU timing from being attributed to GPU frames**
   - NPU timing fields are zero outside `FLOW_NN`.
   - LiteRT timing EMAs reset when the backend closes/reloads.

4. **Adjusted Governor skip thresholds**
   - Normal pressure from skip-rate is now 10%; severe pressure remains 12%.
   - Processing-time and thermal safeguards remain active.
   - Governor still does not use GPU utilization as a reason to raise resolution.

## Validation

- Kotlin telemetry sources and `GovernorSmoke.kt` compile with `kotlinc`.
- Governor + telemetry smoke tests pass.
- Full Android build was not run: this checkout has no `gradlew` script or Gradle wrapper JAR, and no installed Gradle/Android SDK was available in this environment.
- Device benchmark is still required. In particular, verify that `acquireLatestImage()` reduces capture latency without causing unacceptable sequence gaps, and compare image quality after the change.

## Important interpretation

The new `drop_pct` is a processing skip ratio, not the percentage of source frames dropped by ImageReader. Use `capture_gap_pct` and `ring_evicted_pct` for capture/ring behavior. Keep these metrics separate when comparing runs.
