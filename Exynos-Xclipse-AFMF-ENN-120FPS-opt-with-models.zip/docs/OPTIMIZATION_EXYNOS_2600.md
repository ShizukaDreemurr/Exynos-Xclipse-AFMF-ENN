# Tối ưu Max FPS + 1% low ổn định cho Exynos 2600 (E9965)

Bản này chỉnh mặc định và governor theo hướng **ưu tiên FPS cao / 1% low ổn định**, chấp nhận giảm quality hình ảnh.

## Thay đổi đã áp dụng trong code

### 1. Defaults (`FluidSettings`)
| Setting | Cũ | Mới (Max FPS profile) |
|---------|----|------------------------|
| `governorEnabled` | true | **false** |
| `tier` | AUTO (→540p) | **P360** |
| `backend` | AUTO | **NPU** |
| `alwaysInterp` | false | **true** |
| `sensitivity` | 1 | **2** |

Lần cài đặt đầu / clear data sẽ dùng profile này. Người dùng vẫn có thể đổi trong Settings / menu nổi.

### 2. Governor
- AUTO map → **P360** (thay vì P540).
- Ngưỡng pressure thấp hơn (workMs > 70% budget, drop ≥ 6%) → hạ tier sớm hơn.
- Hysteresis tăng tier dài hơn (240 frames) → giảm dao động tier → 1% low ổn định hơn.
- Thermal CRITICAL vẫn force passthrough kể cả khi tắt governor.

### 3. Preset UI
Thêm preset **Max FPS 2600**:
- P360 + NPU + tắt Governor + alwaysInterp + sensitivity 2

### 4. Model export
- `export_tflite.py` mặc định `--precision int8`.
- README hướng dẫn pipeline INT8 cho 640/960/1280.

## Cách dùng trên máy thật

1. Export model INT8 (xem `models/README.md`).
2. Build APK, cài lên máy Exynos 2600.
3. Mở Settings → chọn preset **Max FPS 2600** (hoặc để mặc định).
4. Bật Trợ năng + cấp quyền MediaProjection.
5. Vào game → bật nội suy cho app đó trong menu nổi.
6. Theo dõi HUD: `workMs`, `npu_*`, drop %, thermal. Mục tiêu `workMs` << 16.7 ms.

## Việc còn lại (chưa làm được trong bản này)

- Zero-copy AHardwareBuffer → ENN/LiteCore (hiện vẫn copy float qua CPU).
- Implement `EnnNativeBackend` với SDK thật.
- Async compute queue Vulkan độc lập.
- Model flow đã train + quant tốt (repo không kèm weight).
- Đọc GPU/NPU util từ vendor API Samsung để governor thông minh hơn.

## Gợi ý benchmark

- So sánh: FP16 vs INT8, P360 vs P540, Governor on/off.
- Đo 1% low / 0.1% low qua HUD hoặc Telemetry export XLSX.
- Giữ thermal ≤ Fair càng lâu càng tốt; Critical sẽ passthrough.
