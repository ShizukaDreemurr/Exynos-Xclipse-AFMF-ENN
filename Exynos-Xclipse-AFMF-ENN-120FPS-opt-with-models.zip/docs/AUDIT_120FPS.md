# Audit pipeline — mục tiêu 120 FPS (360p / 560p) trên Exynos 2600

## 1. Luồng hiện tại (capture → present)

```
MediaProjection (ScreenCaptureEngine)
  → FrameRingBuffer (mutex, capacity bounded, latest-frame)
  → FramePipeline.loop (1 worker)
       → Governor.decide
       → [NN path] nnPre (GPU) → nnThread (LiteRT run float copy) → nnPost (GPU warp+present)
       → [GPU path] begin (preprocess + blockmatch) → finish (warp + present fused)
       → [sync path] begin → optional LiteRT → finish
  → Vulkan swapchain present (vsync/FIFO)
```

| Thành phần | Vai trò |
|---|---|
| CPU | Capture callback, ring, governor, LiteRT copy-in/out, submit command buffers |
| GPU (Xclipse) | preprocess, block-match, warp/blend, blit/present |
| NPU | Optical flow inference (khi có model .tflite); path hiện **copy float qua CPU** |

## 2. Bottleneck có bằng chứng trong code

1. **LiteRT copy path** (`LiteRtBackend`): input/output float[] — không zero-copy AHB. Copy-in + inference + copy-out là wall-time chính khi dùng NPU.
2. **Một queue graphics+compute**: không async compute độc lập → overlap GPU stages hạn chế.
3. **Telemetry sai**:
   - `outFps.tick()` đôi khi được gọi 2 lần có chủ đích (I+real) nhưng `workMs` path NN từng nhân `* 0.5` → số liệu governor/HUD không trung thực.
   - Không đo frame pacing (khoảng present→present).
4. **Block-match**: search RANGE=24 cố định; không early-out block tĩnh; chi phí ~O(range²) theo số block — tăng mạnh khi lên 560p/720p.
5. **Ring mutex**: OK ở 60–120 Hz nhưng không lock-free.
6. **Chưa có tier 560p** trước bản này (chỉ 360/540/720).

## 3. Phân biệt latency vs throughput

- Budget 120 Hz ≈ **8.33 ms** giữa hai present.
- Pipeline latency có thể > 8.33 ms nhưng vẫn đạt throughput 120 nếu stage chồng lấp và không tích queue.
- Không được cộng cơ học pre+flow+warp+present để kết luận “không đủ 8.33 ms”.

## 4. Thay đổi đã triển khai (bản này)

| Hạng mục | Thay đổi |
|---|---|
| Telemetry | `onPresented()`, `recordWork()`, `SampleWindow` P50/P99, `pacingMs`, bỏ `workMs * 0.5`, không tick FPS giả |
| Tier | Thêm `ProcTier.P560` (longSide 992) |
| Block-match | Early-out block tĩnh (SAD thô < 0.35); search range adaptive 16/20/24 theo tier qua `pad0` |
| UI/Governor | P560 trong menu, settings, governor order |
| HUD | Hiển thị pacing + p99 |

## 5. Việc chưa làm / cần device

- Zero-copy ENN (cần SDK + `EnnNativeBackend` thật) — **không tuyên bố zero-copy**.
- Async compute queue riêng + semaphore ownership.
- Coarse-to-fine optical flow 2 cấp đầy đủ (hiện chỉ coarse SAD trong block-match).
- Benchmark 360p/560p trên Exynos 2600 thật — **chưa có số liệu phần cứng**.
- Gradle build trong CI vẫn có thể fail nếu thiếu NDK/wrapper (môi trường ngoài scope tối ưu thuật toán).

## 6. Khuyến nghị chạy thử

1. 360p + GPU block-match, targetHz=120, alwaysInterp: đo `pacing_ms` p50/p99, drop%, work_p99.
2. 360p + NPU INT8 (nếu có model): so sánh copy-in/run/copy-out trên HUD.
3. 560p + GPU: xác định bottleneck (pre/block vs warp vs present).
4. Session dài (>15 phút) để xem throttle nhiệt / latency tích tụ.
