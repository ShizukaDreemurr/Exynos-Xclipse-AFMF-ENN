#!/usr/bin/env bash
# Mặc định profile ultra = giảm độ chính xác mạnh, ưu tiên NPU latency + điện.
set -euo pipefail
cd "$(dirname "$0")"
CKPT="${1:-flow.pt}"
CALIB="${2:-calib_pairs.npy}"
PROFILE="${3:-nano}"
if [[ ! -f "$CALIB" ]]; then
  echo "Chưa có $CALIB — python make_calibration.py"
  exit 1
fi
python export_tflite.py --all-tiers --precision int8 --profile "$PROFILE" --calib "$CALIB" --ckpt "$CKPT"
echo "Done profile=$PROFILE. Assets: flow_*_int8.tflite (+ alias flow_*.tflite = low quality)."
