"""FlowNet profiles — nano/ultra cực nhẹ cho NPU latency thấp.

Input [1,6,H,W] → Output [1,5,H/2,W/2]
Profile: full | lite | ultra | nano
"""
import torch
import torch.nn as nn

MAX_FLOW_BY_PROFILE = {
    "full": 24.0,
    "lite": 16.0,
    "ultra": 12.0,
    "nano": 8.0,
}


class ConvBlock(nn.Module):
    def __init__(self, cin, cout, stride=1, k=3):
        super().__init__()
        self.conv = nn.Conv2d(cin, cout, k, stride, k // 2)
        self.act = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.act(self.conv(x))


class FlowNet(nn.Module):
    def __init__(self, profile: str = "nano"):
        super().__init__()
        profile = (profile or "nano").lower()
        if profile not in MAX_FLOW_BY_PROFILE:
            raise ValueError(profile)
        self.profile = profile
        self.max_flow = MAX_FLOW_BY_PROFILE[profile]

        if profile == "full":
            width, n_blocks, k = 32, 4, 3
        elif profile == "lite":
            width, n_blocks, k = 16, 2, 3
        elif profile == "ultra":
            width, n_blocks, k = 12, 1, 3
        else:  # nano: 8 ch, 1 conv 3x3 after stem — tối thiểu còn ra được flow
            width, n_blocks, k = 8, 1, 3

        self.stem = ConvBlock(6, width, stride=2, k=k)
        self.blocks = nn.ModuleList([ConvBlock(width, width, k=k) for _ in range(n_blocks)])
        self.head = nn.Conv2d(width, 5, 3, 1, 1)

    def forward(self, x):
        h = self.stem(x)
        if self.profile == "full":
            h = h + self.blocks[1](self.blocks[0](h))
            h = h + self.blocks[3](self.blocks[2](h))
        elif self.profile == "lite":
            h = h + self.blocks[1](self.blocks[0](h))
        else:
            h = self.blocks[0](h)
        o = self.head(h)
        flow = torch.tanh(o[:, :4]) * self.max_flow
        mask = torch.sigmoid(o[:, 4:5])
        return torch.cat([flow, mask], dim=1)


def build_flow_net(profile: str = "nano") -> FlowNet:
    return FlowNet(profile=profile)


if __name__ == "__main__":
    for p in ("full", "lite", "ultra", "nano"):
        net = FlowNet(p).eval()
        y = net(torch.rand(1, 6, 320, 640))
        n = sum(x.numel() for x in net.parameters())
        print(p, "out", tuple(y.shape), "params", n)
