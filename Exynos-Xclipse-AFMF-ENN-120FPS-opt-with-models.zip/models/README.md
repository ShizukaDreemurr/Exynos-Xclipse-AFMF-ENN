# Model flow — nano/ultra cho NPU nhanh

## Profile
| Profile | width | blocks | MAX_FLOW |
|---------|-------|--------|----------|
| full | 32 | 4 | 24 |
| lite | 16 | 2 | 16 |
| ultra | 12 | 1 | 12 |
| **nano** (mặc định) | 8 | 1 | 8 |

## Load order
nano_int8 → ultra_int8 → lite_int8 → int8 → nano → ultra → lite → plain

## Export
./export_all_int8.sh flow.pt calib_pairs.npy nano

## Hybrid
NPU (copy+run+out) > 70% budget frame nguồn → GPU block-match frame đó.

## HUD
Backend: NPU nano/INT8 · flow_640_nano_int8 + NPU ms in|run|out
