# Xclipse ENN-SS

Nội suy khung hình 30→60 FPS kiểu AFMF cho Android (MediaProjection → Vulkan compute → overlay), flow qua NPU Exynos (LiteRT/ENN) hoặc block-matching GPU.

Module: `core-capture` (MediaProjection + ring buffer) · `core-telemetry` (số liệu, governor) · `core-overlay` (cửa sổ video/HUD/menu) · `core-vulkan` (NDK: AHB import, shader, swapchain) · `core-enn` (backend suy luận) · `app`.

## Mục tiêu 120 FPS (360p / 560p)

Xem [`docs/AUDIT_120FPS.md`](docs/AUDIT_120FPS.md): sửa telemetry trung thực, tier P560, block-match early-out + search range adaptive.

## Profile Max FPS / Exynos 2600 (bản trước)

Mặc định đã chỉnh cho **FPS cao + 1% low ổn định** trên Exynos 2600 (E9965), chấp nhận giảm quality:

- Governor **tắt** theo mặc định → khóa tier cố định
- Tier mặc định **P360** (640)
- Backend mặc định **NPU**
- `alwaysInterp = true`, `sensitivity = 2`
- Governor (khi bật) hạ tier sớm hơn, tăng tier chậm hơn (hysteresis 240 frames)
- Preset UI **Max FPS 2600**
- `export_tflite.py` mặc định **INT8**

Chi tiết: [`docs/OPTIMIZATION_EXYNOS_2600.md`](docs/OPTIMIZATION_EXYNOS_2600.md) · [`models/README.md`](models/README.md)

### Cách dùng nhanh
1. Export model INT8 (640/960/1280) với calib gameplay → bỏ vào `app/src/main/assets/models/`
2. Build & cài APK
3. Settings → preset **Max FPS 2600** (hoặc để mặc định)
4. Bật Trợ năng + MediaProjection → vào game → bật nội suy cho app trong menu nổi

## Trạng thái thật
- **Chưa build, chưa chạy trên thiết bị.** Chỉ `pipeline.cpp` được kiểm cú pháp (header giả). Shader chưa qua glslang.
- Present dùng **Vulkan swapchain + vkCmdBlitImage**, không phải ASurfaceControl/fence AHB.
- Cần bật **dịch vụ Trợ năng** thủ công để cảm ứng xuyên qua ở độ mờ 100%.
- **Rủi ro chưa kiểm:** MediaProjection có thể chụp chính overlay (xem docs/TEST_PLAN.md §2).
- Model Refine chưa nối. Không kèm trọng số flow đã huấn luyện (xem models/README.md).
- Đường LiteRT không zero-copy; `EnnNativeBackend` là stub chờ SDK (docs/ENN_SDK_GUIDE.md).
- Ring buffer dùng mutex (không lock-free).

## Build
Push lên GitHub → Actions build APK debug. Hoặc Android Studio (NDK 27.0.12077973, CMake 3.22.1). Gradle wrapper jar chưa có: chạy `gradle wrapper` một lần.

## Thay đổi gần đây
- Defaults + Governor + preset hướng Max FPS / 1% low ổn định cho Exynos 2600.
- INT8 là precision mặc định khi export model.
- Governor: AUTO → P360, pressure threshold thấp hơn, hysteresis dài hơn.
- Block matching có vòng tìm kiếm thô SAD 4x4, sau đó tinh chỉnh bằng SAD 8x8.

### Giới hạn cần biết
Đây vẫn là tối ưu tầng ứng dụng/shader. Chưa có ENN zero-copy, model đã train, async compute queue độc lập, hay đọc GPU/NPU util từ vendor API. Cần build + benchmark trên thiết bị thật.
