package com.fluidframes.app

/** Ảnh chụp số liệu pipeline — Trang chủ + overlay. */
data class LiveStats(
    val srcFps: Float,
    val outFps: Float,
    val mode: String,
    val tier: String,
    val backend: String,
    val modelProfile: String = "—",
    val modelFile: String = "—",
    val workMs: Float,
    val dropPct: Float,
    val thermal: Int,
)
