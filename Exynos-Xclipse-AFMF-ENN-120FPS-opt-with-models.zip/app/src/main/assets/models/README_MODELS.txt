FluidFrames flow models — nano profile
=====================================
Weights: RANDOM (not trained). Only for pipeline / NPU load / latency testing.
Quality: poor motion, ghosting expected.
Quant: FP32/FP16 graph from litert_torch (file names *_int8* are aliases for loader priority; not true INT8 quant).

Shapes: input [1,6,H,W] float32, output [1,5,H/2,W/2] float32
Tiers longSide: 256,320,416,480,640,960,992,1280 (H,W fixed at export for 20:9)

To train: distill from RIFE/IFRNet then re-export with real ckpt + INT8 calib.
