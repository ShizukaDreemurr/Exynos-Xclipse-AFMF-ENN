package com.fluidframes.overlay

/** Snapshot số liệu để bảng menu overlay đọc (cập nhật từ pipeline). */
object LiveHudCache {
    @Volatile var backend: String = "—"
    @Volatile var modelProfile: String = "—"
    @Volatile var modelFile: String = "—"
    @Volatile var tier: String = "—"
    @Volatile var mode: String = "—"
}
