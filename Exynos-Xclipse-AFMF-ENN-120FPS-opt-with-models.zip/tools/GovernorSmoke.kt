import com.fluidframes.telemetry.*

fun main() {
    val g = Governor()
    fun input(adaptive: Boolean, work: Float, drop: Float, thermal: Int = 0) = Governor.Input(
        enabled = true, adaptiveEnabled = adaptive, prefTier = ProcTier.P720,
        prefBackend = FlowBackend.GPU, npuAvailable = false, srcFps = 30f,
        workMs = work, dropRate = drop, thermalStatus = thermal
    )

    check(g.decide(input(false, 40f, 0.5f)).tier == ProcTier.P720) {
        "disabled governor must lock tier"
    }
    check(g.decide(input(true, 0f, 0.065f)).tier == ProcTier.P720) {
        "small skip-rate noise must not downshift tier"
    }
    check(g.decide(input(true, 20f, 0.15f)).tier == ProcTier.P360) {
        "severe pressure must reduce tier"
    }
    check(g.decide(input(false, 0f, 0f, 4)).mode == Mode.PASSTHROUGH) {
        "critical thermal guard must remain active"
    }

    val stats = PipelineStats()
    repeat(10) { stats.framesIn.incrementAndGet() }
    stats.framesSkipped.addAndGet(2)
    check(kotlin.math.abs(stats.dropRate() - 0.2f) < 0.0001f) {
        "drop rate must use skipped processing frames / consumed frames"
    }
    println("Governor and telemetry smoke tests passed")
}
