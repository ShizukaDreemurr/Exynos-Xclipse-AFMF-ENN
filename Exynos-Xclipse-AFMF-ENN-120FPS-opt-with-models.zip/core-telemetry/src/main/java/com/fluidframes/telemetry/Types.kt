package com.fluidframes.telemetry

/** Chế độ xử lý một frame. */
enum class Mode { PASSTHROUGH, FLOW_GPU, FLOW_NN }

/**
 * Độ phân giải xử lý — longSide bội 32.
 * Các mức thấp (P270↓) để NPU/GPU nhẹ khi target 120 FPS.
 */
enum class ProcTier(val label: String, val longSide: Int) {
    AUTO("Mặc định (360p)", 0),
    P720("720p", 1280),
    P560("560p", 992),
    P540("540p", 960),
    P360("360p", 640),
    /** ~270p */
    P270("270p", 480),
    /** ~240p */
    P240("240p", 416),
    /** ~180p */
    P180("180p", 320),
    /** ~120p — cực nhẹ */
    P120("120p", 256),
}

enum class FlowBackend(val label: String) {
    AUTO("Tự động"),
    NPU("NPU (ENN/LiteRT)"),
    GPU("GPU block-match"),
    OFF("Tắt (passthrough)"),
}
