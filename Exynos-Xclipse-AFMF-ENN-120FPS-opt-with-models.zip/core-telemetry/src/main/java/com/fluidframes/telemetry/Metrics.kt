package com.fluidframes.telemetry

import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** Trung bình trượt mũ; ghi từ 1 thread, đọc từ thread khác. */
class Ema(private val alpha: Float = 0.1f) {
    @Volatile var value: Float = 0f
        private set
    private var primed = false
    @Volatile var count: Int = 0
        private set

    fun reset() { primed = false; count = 0; value = 0f }

    fun add(x: Float) {
        count++
        if (!primed) {
            primed = true
            value = x
        } else {
            value += alpha * (x - value)
        }
    }
}

/**
 * Cửa sổ mẫu cố định để ước lượng percentile (P50/P90/P95/P99).
 * Không thay EMA; dùng song song cho pacing / work time.
 */
class SampleWindow(private val capacity: Int = 240) {
    private val buf = FloatArray(capacity)
    private var n = 0
    private var idx = 0

    @Synchronized
    fun add(x: Float) {
        buf[idx] = x
        idx = (idx + 1) % capacity
        if (n < capacity) n++
    }

    @Synchronized
    fun reset() { n = 0; idx = 0 }

    /** percentile in [0,1]; trả 0 nếu chưa có mẫu. */
    @Synchronized
    fun percentile(p: Float): Float {
        if (n <= 0) return 0f
        val tmp = buf.copyOf(n)
        tmp.sort()
        val i = ((n - 1) * p.coerceIn(0f, 1f)).toInt().coerceIn(0, n - 1)
        return tmp[i]
    }

    @Synchronized fun p50() = percentile(0.50f)
    @Synchronized fun p90() = percentile(0.90f)
    @Synchronized fun p95() = percentile(0.95f)
    @Synchronized fun p99() = percentile(0.99f)
    @Synchronized fun size() = n
}

/** Đếm sự kiện trong 1 giây gần nhất — mỗi tick = một sự kiện thật (không tick kép). */
class FpsCounter {
    private val stamps = ArrayDeque<Long>()

    @Synchronized
    fun tick(nowNs: Long = System.nanoTime()) {
        stamps.addLast(nowNs)
        trim(nowNs)
    }

    @Synchronized
    fun fps(nowNs: Long = System.nanoTime()): Float {
        trim(nowNs)
        return stamps.size.toFloat()
    }

    private fun trim(nowNs: Long) {
        while (stamps.isNotEmpty() && nowNs - stamps.peekFirst()!! > 1_000_000_000L) stamps.pollFirst()
    }
}

inline fun <T> Ema.measureMs(block: () -> T): T {
    val t0 = System.nanoTime()
    try {
        return block()
    } finally {
        add((System.nanoTime() - t0) / 1_000_000f)
    }
}

/**
 * Số liệu pipeline — phân tách rõ nguồn / nội suy / trình bày.
 *
 * Quy ước tick:
 * - srcFps: mỗi frame capture được consumer nhận (1 lần / frame nguồn)
 * - interpFps: mỗi frame nội suy thực sự được tạo
 * - presentedFps / outFps: mỗi lần present thành công lên swapchain (interp hoặc real)
 * Không được tick outFps hai lần cho cùng một present.
 */
class PipelineStats {
    val srcFps = FpsCounter()
    /** FPS thực sự present lên màn (swapchain). Alias lịch sử: outFps. */
    val outFps = FpsCounter()
    val presentedFps get() = outFps
    val interpFps = FpsCounter()
    /** Frame bị lặp (present lại nội dung cũ) nếu pipeline phát hiện. */
    val duplicateFps = FpsCounter()

    val captureMs = Ema()
    val preMs = Ema()      // GPU preprocess (+ block-match nếu dùng)
    val flowMs = Ema()     // NN inference (CPU wall) hoặc 0 — chỉ khi frame chạy NN
    val warpMs = Ema()     // GPU warp + blend + occlusion
    val presentMs = Ema()  // thời gian chờ present (vsync / FIFO)
    val workMs = Ema()     // CPU-side work cho 1 quyết định frame (không nhân hệ số giả)
    /** Khoảng thời gian giữa hai lần present thành công (ms) — frame pacing. */
    val pacingMs = Ema()
    val pacingWindow = SampleWindow(240)
    val workWindow = SampleWindow(240)

    val framesIn = AtomicLong()
    val framesInterp = AtomicLong()
    val framesPassthrough = AtomicLong()
    val framesSkipped = AtomicLong()
    val framesDuplicate = AtomicLong()
    val captureGapFrames = AtomicLong()
    val ringDropped = AtomicLong()
    val ringPushed = AtomicLong()
    /** Độ sâu queue xử lý / pending GPU (ước lượng). */
    val queueDepth = AtomicInteger(0)

    private var lastPresentNs = 0L

    /** Gọi đúng 1 lần mỗi present thành công. Cập nhật pacing. */
    fun onPresented(nowNs: Long = System.nanoTime()) {
        if (lastPresentNs > 0L) {
            val dt = (nowNs - lastPresentNs) / 1e6f
            if (dt > 0f && dt < 200f) {
                pacingMs.add(dt)
                pacingWindow.add(dt)
            }
        }
        lastPresentNs = nowNs
        outFps.tick(nowNs)
    }

    fun recordWork(ms: Float) {
        workMs.add(ms)
        workWindow.add(ms)
    }

    /** Tỷ lệ quyết định không tạo frame nội suy trên số frame đã xử lý. */
    fun dropRate(): Float {
        val n = framesIn.get()
        return if (n <= 0L) 0f else framesSkipped.get().toFloat() / n.toFloat()
    }

    fun duplicateRate(): Float {
        val n = framesIn.get()
        return if (n <= 0L) 0f else framesDuplicate.get().toFloat() / n.toFloat()
    }
}
