#!/usr/bin/env bash
# Ép xuất INT8 đủ tier 360/540/560/720 cho Exynos 2600.
set -euo pipefail
cd "$(dirname "$0")"
CKPT="${1:-flow.pt}"
CALIB="${2:-calib_pairs.npy}"
if [[ ! -f "$CALIB" ]]; then
  echo "Chưa có $CALIB — chạy: python make_calibration.py"
  exit 1
fi
python export_tflite.py --all-tiers --precision int8 --calib "$CALIB" --ckpt "$CKPT"
echo "Xong. Copy app/src/main/assets/models/flow_*.tflite vào APK assets."
