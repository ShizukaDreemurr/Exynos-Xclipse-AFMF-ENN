"""Mạng flow theo hợp đồng FluidFrames — có profile giảm chất lượng cho NPU nhanh / ít điện.

Input : [1,6,H,W]  prev RGB + cur RGB, 0..1, H,W bội số 32
Output: [1,5,H/2,W/2] = F_t->0 (x,y), F_t->1 (x,y) pixel proc-res; mask (sigmoid)

Profile:
  full  — width=32, 4 block (gốc)
  lite  — width=16, 2 block  (~1/2–1/3 MACs, độ chính xác thấp hơn rõ)
  ultra — width=12, 1 block  (~1/4–1/5 MACs, chấp nhận flow thô / ghosting)

Chỉ Conv2d + ReLU + add + tanh/sigmoid. Không grid_sample (warp trên Vulkan).
"""
import torch
import torch.nn as nn

# Biên độ flow max (pixel proc-res). Ultra/lite nhỏ hơn → NPU ít “cố” khớp chuyển động lớn.
MAX_FLOW_BY_PROFILE = {
    "full": 24.0,
    "lite": 16.0,
    "ultra": 12.0,
}


class ConvBlock(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.conv = nn.Conv2d(cin, cout, 3, stride, 1)
        self.act = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.act(self.conv(x))


class FlowNet(nn.Module):
    """profile: full | lite | ultra"""

    def __init__(self, profile: str = "lite"):
        super().__init__()
        profile = (profile or "lite").lower()
        if profile not in MAX_FLOW_BY_PROFILE:
            raise ValueError(f"profile phải là full|lite|ultra, nhận: {profile}")
        self.profile = profile
        self.max_flow = MAX_FLOW_BY_PROFILE[profile]

        if profile == "full":
            width, n_blocks = 32, 4
        elif profile == "lite":
            width, n_blocks = 16, 2
        else:  # ultra
            width, n_blocks = 12, 1

        self.stem = ConvBlock(6, width, stride=2)  # H,W -> H/2,W/2
        blocks = []
        for _ in range(n_blocks):
            blocks.append(ConvBlock(width, width))
        self.blocks = nn.ModuleList(blocks)
        self.head = nn.Conv2d(width, 5, 3, 1, 1)
        # Cặp residual: full dùng 2 cặp; lite 1 cặp; ultra không residual (1 block tuần tự)
        self.use_residual_pairs = profile == "full" or (profile == "lite" and n_blocks >= 2)

    def forward(self, x):
        h = self.stem(x)
        if self.profile == "full":
            h = h + self.blocks[1](self.blocks[0](h))
            h = h + self.blocks[3](self.blocks[2](h))
        elif self.profile == "lite":
            h = h + self.blocks[1](self.blocks[0](h))
        else:
            h = self.blocks[0](h)
        o = self.head(h)
        flow = torch.tanh(o[:, :4]) * self.max_flow
        mask = torch.sigmoid(o[:, 4:5])
        return torch.cat([flow, mask], dim=1)


def build_flow_net(profile: str = "lite") -> FlowNet:
    return FlowNet(profile=profile)


if __name__ == "__main__":
    for p in ("full", "lite", "ultra"):
        net = FlowNet(p).eval()
        y = net(torch.rand(1, 6, 320, 640))
        n = sum(x.numel() for x in net.parameters())
        print(p, "out", tuple(y.shape), "params", n)
