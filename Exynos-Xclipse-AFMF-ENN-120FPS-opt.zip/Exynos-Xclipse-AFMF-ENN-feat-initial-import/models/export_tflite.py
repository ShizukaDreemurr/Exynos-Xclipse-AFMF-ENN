"""Xuất FlowNet -> .tflite — mặc định INT8 cho Exynos 2600 / LiteCore.

INT8 giảm latency, bandwidth và nhiệt so với FP16/FP32 (chấp nhận mất quality).

Cài:
    pip install torch ai-edge-torch ai-edge-quantizer numpy

Xuất 1 tier:
    python make_calibration.py
    python export_tflite.py --long-side 640 --calib calib_pairs.npy --ckpt flow.pt

Xuất đủ tier 120FPS profile (360 / 540 / 560 / 720):
    python export_tflite.py --all-tiers --calib calib_pairs.npy --ckpt flow.pt

File ra:
    app/src/main/assets/models/flow_<longSide>.tflite
    app/src/main/assets/models/flow_<longSide>_int8.tflite  (bản sao cùng INT8, runtime ưu tiên)
"""
import argparse
import os
import shutil
import sys

import numpy as np
import torch

from flow_net import FlowNet

# longSide khớp ProcTier: P360=640, P540=960, P560=992, P720=1280
DEFAULT_TIERS = (640, 960, 992, 1280)


def proc_size(long_side, aspect):
    aw, ah = (float(v) for v in aspect.split(":"))
    w = long_side
    h = long_side * ah / aw
    return (int(w) // 32) * 32, max(64, (int(h) // 32) * 32)


def export_one(long_side, aspect, precision, ckpt, calib, out_dir):
    w, h = proc_size(long_side, aspect)
    print(f"[export] long_side={long_side} proc={w}x{h} precision={precision}")

    net = FlowNet().eval()
    if ckpt:
        net.load_state_dict(torch.load(ckpt, map_location="cpu"))
    else:
        print("CẢNH BÁO: không có --ckpt, xuất trọng số ngẫu nhiên (chỉ kiểm tra pipeline).")

    sample = (torch.rand(1, 6, h, w),)

    import ai_edge_torch

    edge_model = ai_edge_torch.convert(net, sample)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"flow_{long_side}.tflite")

    if precision == "fp32":
        edge_model.export(path)
    else:
        tmp = path + ".fp32"
        edge_model.export(tmp)
        from ai_edge_quantizer import quantizer, recipe

        qt = quantizer.Quantizer(tmp)
        if precision == "fp16":
            qt.load_quantization_recipe(recipe.weight_only_wfp16_afp32())
            qt.quantize().export_model(path)
        else:
            if not calib:
                raise SystemExit("INT8 bắt buộc --calib (make_calibration.py)")
            qt.load_quantization_recipe(recipe.static_wi8_ai8())
            data = np.load(calib).astype(np.float32)
            cal = {"serving_default": [{"args_0": data[i : i + 1]} for i in range(len(data))]}
            res = qt.calibrate(cal)
            qt.quantize(res).export_model(path)
        try:
            os.remove(tmp)
        except OSError:
            pass

    # Bản đặt tên rõ INT8 để runtime ưu tiên (cùng nội dung khi precision=int8).
    if precision == "int8":
        int8_path = os.path.join(out_dir, f"flow_{long_side}_int8.tflite")
        shutil.copy2(path, int8_path)
        print("Đã ghi", path)
        print("Đã ghi", int8_path)
    else:
        print("Đã ghi", path)
    return path


def main():
    ap = argparse.ArgumentParser(description="Export FlowNet TFLite (default INT8)")
    ap.add_argument("--long-side", type=int, default=None, help="một tier; bỏ qua nếu --all-tiers")
    ap.add_argument("--all-tiers", action="store_true", help="xuất 640,960,992,1280")
    ap.add_argument("--aspect", default="20:9")
    ap.add_argument("--precision", choices=["fp32", "fp16", "int8"], default="int8")
    ap.add_argument("--ckpt", default=None)
    ap.add_argument("--calib", default=None)
    ap.add_argument("--out", default="../app/src/main/assets/models")
    args = ap.parse_args()

    if args.precision == "int8" and not args.calib:
        print("INT8 cần --calib. Ví dụ: python make_calibration.py && python export_tflite.py --all-tiers --calib calib_pairs.npy --ckpt flow.pt", file=sys.stderr)
        raise SystemExit(2)

    sides = list(DEFAULT_TIERS) if args.all_tiers else [args.long_side]
    if not args.all_tiers and args.long_side is None:
        raise SystemExit("Cần --long-side N hoặc --all-tiers")

    for side in sides:
        export_one(side, args.aspect, args.precision, args.ckpt, args.calib, args.out)


if __name__ == "__main__":
    main()
