"""Xuất FlowNet -> .tflite. Mặc định INT8 + profile lite (giảm chất lượng, NPU nhanh hơn).

Profiles (chất lượng giảm dần, tốc độ tăng):
  full  — mạng gốc width=32
  lite  — ~1/2–1/3 MACs (mặc định)
  ultra — ~1/4–1/5 MACs, flow thô, ưu tiên latency/điện

Cài: pip install torch ai-edge-torch ai-edge-quantizer numpy

  python make_calibration.py
  python export_tflite.py --all-tiers --profile nano --calib calib_pairs.npy --ckpt flow.pt
  python export_tflite.py --all-tiers --profile lite  --calib calib_pairs.npy --ckpt flow.pt

Runtime ưu tiên: flow_<side>_ultra_int8.tflite > ..._lite_int8 > ..._int8 > flow_<side>.tflite
"""
import argparse
import os
import shutil
import sys

import numpy as np
import torch

from flow_net import FlowNet

DEFAULT_TIERS = (640, 960, 992, 1280)


def proc_size(long_side, aspect):
    aw, ah = (float(v) for v in aspect.split(":"))
    w = long_side
    h = long_side * ah / aw
    return (int(w) // 32) * 32, max(64, (int(h) // 32) * 32)


def export_one(long_side, aspect, precision, profile, ckpt, calib, out_dir):
    w, h = proc_size(long_side, aspect)
    print(f"[export] side={long_side} proc={w}x{h} precision={precision} profile={profile}")

    net = FlowNet(profile=profile).eval()
    if ckpt:
        # Checkpoint full có thể không khớp lite/ultra — chỉ load khi shape khớp
        try:
            sd = torch.load(ckpt, map_location="cpu")
            net.load_state_dict(sd, strict=True)
            print("  loaded ckpt strict")
        except Exception as e:
            print(f"  CẢNH BÁO: không load được ckpt vào profile={profile} ({e}). Dùng trọng số random — chỉ để đo latency pipeline.")
    else:
        print("  CẢNH BÁO: không --ckpt, trọng số random.")

    sample = (torch.rand(1, 6, h, w),)
    import ai_edge_torch

    edge_model = ai_edge_torch.convert(net, sample)
    os.makedirs(out_dir, exist_ok=True)

    # Tên file: flow_640_ultra_int8.tflite / flow_640_lite.tflite / flow_640.tflite
    tag = "" if profile == "full" else f"_{profile}"
    base = f"flow_{long_side}{tag}"
    path = os.path.join(out_dir, f"{base}.tflite")

    if precision == "fp32":
        edge_model.export(path)
    else:
        tmp = path + ".fp32"
        edge_model.export(tmp)
        from ai_edge_quantizer import quantizer, recipe

        qt = quantizer.Quantizer(tmp)
        if precision == "fp16":
            qt.load_quantization_recipe(recipe.weight_only_wfp16_afp32())
            qt.quantize().export_model(path)
        else:
            if not calib:
                raise SystemExit("INT8 cần --calib")
            qt.load_quantization_recipe(recipe.static_wi8_ai8())
            data = np.load(calib).astype(np.float32)
            # calib có thể khác H,W — quantizer dùng shape model; nếu lệch, tạo dummy từ sample
            try:
                cal = {"serving_default": [{"args_0": data[i : i + 1]} for i in range(min(len(data), 32))]}
                res = qt.calibrate(cal)
                qt.quantize(res).export_model(path)
            except Exception as e:
                print(f"  calib shape mismatch ({e}), fallback random calib tensors")
                rnd = [np.random.rand(1, 6, h, w).astype(np.float32) for _ in range(8)]
                cal = {"serving_default": [{"args_0": x} for x in rnd]}
                res = qt.calibrate(cal)
                qt.quantize(res).export_model(path)
        try:
            os.remove(tmp)
        except OSError:
            pass

    print("  wrote", path)
    # Bản đặt tên int8 rõ + alias flow_<side>.tflite khi profile lite/ultra để app cũ vẫn thấy file
    if precision == "int8":
        int8_named = os.path.join(out_dir, f"{base}_int8.tflite")
        shutil.copy2(path, int8_named)
        print("  wrote", int8_named)
        if profile in ("lite", "ultra", "nano"):
            # alias chính flow_<side>.tflite = bản low-quality (ép app dùng model nhẹ)
            alias = os.path.join(out_dir, f"flow_{long_side}.tflite")
            shutil.copy2(path, alias)
            print("  wrote alias", alias, f"(= {profile} INT8, ép chất lượng thấp)")
            alias_i = os.path.join(out_dir, f"flow_{long_side}_int8.tflite")
            shutil.copy2(path, alias_i)
            print("  wrote alias", alias_i)
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--long-side", type=int, default=None)
    ap.add_argument("--all-tiers", action="store_true")
    ap.add_argument("--aspect", default="20:9")
    ap.add_argument("--precision", choices=["fp32", "fp16", "int8"], default="int8")
    ap.add_argument("--profile", choices=["full", "lite", "ultra", "nano"], default="nano",
                    help="mặc định nano = giảm chất lượng mạnh, NPU nhanh/ít điện")
    ap.add_argument("--ckpt", default=None)
    ap.add_argument("--calib", default=None)
    ap.add_argument("--out", default="../app/src/main/assets/models")
    args = ap.parse_args()

    if args.precision == "int8" and not args.calib:
        print("INT8 cần --calib", file=sys.stderr)
        raise SystemExit(2)
    sides = list(DEFAULT_TIERS) if args.all_tiers else [args.long_side]
    if not args.all_tiers and args.long_side is None:
        raise SystemExit("Cần --long-side hoặc --all-tiers")

    for side in sides:
        export_one(side, args.aspect, args.precision, args.profile, args.ckpt, args.calib, args.out)


if __name__ == "__main__":
    main()
