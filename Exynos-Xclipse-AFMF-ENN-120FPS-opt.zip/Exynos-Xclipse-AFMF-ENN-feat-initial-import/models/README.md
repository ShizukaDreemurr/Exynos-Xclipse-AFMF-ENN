# Model flow — giảm chất lượng để NPU nhanh / ít điện

## Profile (chất lượng ↓ = tốc độ ↑)

| Profile | width | blocks | MAX_FLOW | Ước lượng MACs | Khi nào dùng |
|---------|-------|--------|----------|----------------|--------------|
| full | 32 | 4 | 24px | 100% | Chất lượng cao, chấp nhận latency |
| lite | 16 | 2 | 16px | ~30–50% | Cân bằng |
| **ultra** (mặc định export) | 12 | 1 | 12px | ~20–25% | **120 FPS / ít điện, chấp nhận ghosting** |

## Asset runtime (thứ tự ưu tiên load)

1. `flow_<side>_ultra_int8.tflite`
2. `flow_<side>_lite_int8.tflite`
3. `flow_<side>_int8.tflite`
4. `flow_<side>_ultra.tflite` / `_lite.tflite`
5. `flow_<side>.tflite`

`export` với `--profile ultra` còn ghi **alias** `flow_<side>.tflite` = bản ultra INT8 để ép mọi đường load dùng model nhẹ.

## Export

```bash
cd models
python make_calibration.py
# mạnh nhất (mặc định):
./export_all_int8.sh flow.pt calib_pairs.npy ultra
# hoặc:
python export_tflite.py --all-tiers --profile ultra --precision int8 --calib calib_pairs.npy --ckpt flow.pt
```

Tier longSide: 640, 960, 992, 1280.

## Lưu ý

- Checkpoint train cho `full` **không** load vào `lite`/`ultra` (khác shape). Cần distill/train lại từng profile, hoặc export random chỉ để đo latency.
- INT8 + ultra = giảm độ chính xác **có chủ đích** (đúng yêu cầu trade-off).
- Biên LiteRT vẫn float copy — chưa zero-copy AHB.
