# Mô hình flow — ép INT8 cho Exynos 2600

## Hợp đồng I/O
| | |
|---|---|
| Input | float32 NCHW `[1,6,H,W]` — prev RGB, cur RGB, 0..1; H,W bội 32 |
| Output | float32 NCHW `[1,5,H/2,W/2]` — flow 2 chiều + mask |
| Asset (ưu tiên) | `models/flow_<longSide>_int8.tflite` |
| Asset (fallback) | `models/flow_<longSide>.tflite` |
| Tier longSide | 640 (360p), 960 (540p), **992 (560p)**, 1280 (720p) |

Runtime (`LiteRtBackend`) **thử `_int8` trước**. Không có file → GPU block-match.

> Lưu ý: quant INT8 nằm trong file model; đường LiteRT hiện vẫn copy float[] ở biên I/O (chưa zero-copy AHB).

## Ép xuất INT8 (bắt buộc calib)

```bash
cd models
python make_calibration.py          # calib_pairs.npy từ gameplay
# một lệnh đủ 4 tier:
./export_all_int8.sh flow.pt calib_pairs.npy
# hoặc:
python export_tflite.py --all-tiers --precision int8 --calib calib_pairs.npy --ckpt flow.pt
```

`--precision` mặc định đã là **int8**. Mỗi tier ghi:
- `flow_<side>.tflite`
- `flow_<side>_int8.tflite` (cùng nội dung, tên rõ quant)

## Op NPU hay từ chối
| Op | Xử lý |
|---|---|
| grid_sample | warp trên Vulkan |
| Dynamic shape | một file / tier |
| PReLU / LayerNorm | ReLU + BN fold |
| FP32 lớn | **INT8** |

## Quality
INT8 có thể ghosting / flow sai hơn FP16. Đó là đánh đổi có chủ đích cho latency + 120 FPS target. So sánh visual trước khi ship.
