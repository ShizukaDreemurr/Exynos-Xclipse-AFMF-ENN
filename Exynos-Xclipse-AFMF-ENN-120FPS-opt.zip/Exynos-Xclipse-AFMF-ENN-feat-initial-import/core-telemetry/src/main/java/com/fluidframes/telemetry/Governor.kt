package com.fluidframes.telemetry

/**
 * Governor thích ứng có hysteresis — tối ưu cho 1% low ổn định trên Exynos 2600.
 * - Khi bật: giảm tier sớm hơn khi workMs/drop/thermal có dấu hiệu áp lực;
 *   chỉ tăng tier sau khoảng ổn định dài hơn để tránh dao động (jitter).
 * - Khi tắt: giữ đúng tier người dùng chọn (AUTO = 360p trong profile Max FPS).
 * - Bảo vệ nhiệt CRITICAL vẫn có hiệu lực kể cả khi tắt governor.
 *
 * Ngưỡng được chỉnh aggressive hơn bản gốc để ưu tiên FPS ổn định hơn chất lượng.
 * Chưa đọc GPU/NPU utilization theo vendor API Samsung.
 */
class Governor {
    data class Input(
        val enabled: Boolean,
        val adaptiveEnabled: Boolean = true,
        val prefTier: ProcTier,
        val prefBackend: FlowBackend,
        val npuAvailable: Boolean,
        val srcFps: Float,
        val workMs: Float,
        val dropRate: Float,
        val thermalStatus: Int,
    )

    data class Decision(val mode: Mode, val tier: ProcTier)

    // Mặc định thấp hơn để khởi đầu an toàn hơn trên 2600.
    private var activeTier = ProcTier.P360
    private var stableFrames = 0
    private var lastPrefTier = ProcTier.AUTO
    private var lastAdaptive = true

    fun reset() {
        activeTier = ProcTier.P360
        stableFrames = 0
        lastPrefTier = ProcTier.AUTO
        lastAdaptive = true
    }

    fun decide(i: Input): Decision {
        if (!i.enabled || i.prefBackend == FlowBackend.OFF) return pass()
        // Luôn giữ chốt bảo vệ nhiệt khẩn cấp, kể cả khi governor bị tắt.
        if (i.thermalStatus >= 4) return pass()

        // AUTO trong profile Max FPS = P360 (thay vì P540) để latency thấp hơn.
        val requested = if (i.prefTier == ProcTier.AUTO) ProcTier.P360 else i.prefTier
        if (requested != lastPrefTier || i.adaptiveEnabled != lastAdaptive) {
            activeTier = requested
            stableFrames = 0
            lastPrefTier = i.prefTier
            lastAdaptive = i.adaptiveEnabled
        }

        if (!i.adaptiveEnabled) {
            activeTier = requested
        } else {
            val frameBudgetMs = if (i.srcFps > 1f) 500f / i.srcFps else 16.67f
            // Ngưỡng pressure thấp hơn (0.70 / 0.06) → hạ tier sớm hơn, giảm spike 1% low.
            val pressure = i.thermalStatus >= 3 ||
                (i.workMs > frameBudgetMs * 0.70f && i.workMs > 0f) ||
                i.dropRate >= 0.06f
            val severePressure = i.thermalStatus >= 3 ||
                (i.workMs > frameBudgetMs * 0.95f && i.workMs > 0f) ||
                i.dropRate >= 0.10f

            if (pressure) {
                stableFrames = 0
                activeTier = lower(activeTier, requested, severePressure)
            } else {
                stableFrames++
                // Hysteresis dài hơn (240 frames ≈ 4s @ 60Hz) để tránh dao động tier.
                if (stableFrames >= 240 && i.thermalStatus <= 1 &&
                    (i.workMs <= 0f || i.workMs < frameBudgetMs * 0.50f) && i.dropRate < 0.005f) {
                    activeTier = higher(activeTier, requested)
                    stableFrames = 0
                }
            }
        }

        val nn = i.prefBackend != FlowBackend.GPU && i.npuAvailable
        return Decision(if (nn) Mode.FLOW_NN else Mode.FLOW_GPU, activeTier)
    }

    private fun lower(current: ProcTier, floor: ProcTier, severe: Boolean): ProcTier {
        val order = listOf(ProcTier.P720, ProcTier.P560, ProcTier.P540, ProcTier.P360)
        val idx = order.indexOf(current).coerceAtLeast(order.indexOf(floor).coerceAtLeast(0))
        return order[minOf(order.lastIndex, idx + if (severe) 2 else 1)]
    }

    private fun higher(current: ProcTier, ceiling: ProcTier): ProcTier {
        val order = listOf(ProcTier.P720, ProcTier.P560, ProcTier.P540, ProcTier.P360)
        val idx = order.indexOf(current).coerceAtLeast(0)
        val ceilingIdx = order.indexOf(ceiling).coerceAtLeast(0)
        return order[maxOf(ceilingIdx, idx - 1)]
    }

    private fun pass() = Decision(Mode.PASSTHROUGH, ProcTier.P360)
}
