package com.fluidframes.telemetry

/** Chế độ xử lý một frame. */
enum class Mode { PASSTHROUGH, FLOW_GPU, FLOW_NN }

/**
 * Độ phân giải xử lý (kích thước đầu vào NN / block-match). [longSide] tính theo cạnh dài,
 * cạnh ngắn suy ra theo tỉ lệ màn hình và làm tròn bội số 32.
 *
 * Mục tiêu 120 FPS:
 * - P360 (640): cấu hình nhẹ, ưu tiên throughput ổn định.
 * - P560 (992 ≈ 560p): multi-res / coarse-to-fine, chi phí cao hơn — không giả định đạt 120 như P360.
 */
enum class ProcTier(val label: String, val longSide: Int) {
    AUTO("Mặc định (360p)", 0),
    P720("720p", 1280),
    /** ~560p: cạnh dài 992 (bội 32). */
    P560("560p", 992),
    P540("540p", 960),
    P360("360p", 640),
}

enum class FlowBackend(val label: String) {
    AUTO("Tự động"),
    NPU("NPU (ENN/LiteRT)"),
    GPU("GPU block-match"),
    OFF("Tắt (passthrough)"),
}
