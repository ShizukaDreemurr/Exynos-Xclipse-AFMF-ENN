package com.fluidframes.telemetry

/**
 * Governor thích ứng có hysteresis.
 * - Khi bật: giảm tier khi thời gian xử lý/drop/thermal cho thấy nguy cơ trễ deadline;
 *   chỉ tăng tier sau một khoảng ổn định đủ dài để tránh dao động liên tục.
 * - Khi tắt: giữ tier người dùng chọn (AUTO = 540p), không tự điều chỉnh theo tải.
 * - Bảo vệ nhiệt CRITICAL vẫn có hiệu lực kể cả khi người dùng tắt governor.
 *
 * Đây là governor dựa trên telemetry hiện có. Chưa tự đọc GPU/NPU utilization theo vendor API.
 */
class Governor {
    data class Input(
        val enabled: Boolean,
        val adaptiveEnabled: Boolean = true,
        val prefTier: ProcTier,
        val prefBackend: FlowBackend,
        val npuAvailable: Boolean,
        val srcFps: Float,
        val workMs: Float,
        val dropRate: Float,
        val thermalStatus: Int,
    )

    data class Decision(val mode: Mode, val tier: ProcTier)

    private var activeTier = ProcTier.P540
    private var stableFrames = 0
    private var lastPrefTier = ProcTier.AUTO
    private var lastAdaptive = true

    fun reset() {
        activeTier = ProcTier.P540
        stableFrames = 0
        lastPrefTier = ProcTier.AUTO
        lastAdaptive = true
    }

    fun decide(i: Input): Decision {
        if (!i.enabled || i.prefBackend == FlowBackend.OFF) return pass()
        // Luôn giữ chốt bảo vệ nhiệt khẩn cấp, kể cả khi governor bị tắt.
        if (i.thermalStatus >= 4) return pass()

        val requested = if (i.prefTier == ProcTier.AUTO) ProcTier.P540 else i.prefTier
        if (requested != lastPrefTier || i.adaptiveEnabled != lastAdaptive) {
            activeTier = requested
            stableFrames = 0
            lastPrefTier = i.prefTier
            lastAdaptive = i.adaptiveEnabled
        }

        if (!i.adaptiveEnabled) {
            activeTier = requested
        } else {
            val frameBudgetMs = if (i.srcFps > 1f) 500f / i.srcFps else 16.67f
            val pressure = i.thermalStatus >= 3 ||
                (i.workMs > frameBudgetMs * 0.82f && i.workMs > 0f) ||
                i.dropRate >= 0.06f
            val severePressure = i.thermalStatus >= 3 ||
                (i.workMs > frameBudgetMs * 1.05f && i.workMs > 0f) ||
                i.dropRate >= 0.12f

            if (pressure) {
                stableFrames = 0
                activeTier = lower(activeTier, requested, severePressure)
            } else {
                stableFrames++
                // Hysteresis: cần 180 quyết định ổn định mới thử tăng một bậc.
                if (stableFrames >= 180 && i.thermalStatus <= 1 &&
                    (i.workMs <= 0f || i.workMs < frameBudgetMs * 0.55f) && i.dropRate < 0.01f) {
                    activeTier = higher(activeTier, requested)
                    stableFrames = 0
                }
            }
        }

        val nn = i.prefBackend != FlowBackend.GPU && i.npuAvailable
        return Decision(if (nn) Mode.FLOW_NN else Mode.FLOW_GPU, activeTier)
    }

    private fun lower(current: ProcTier, floor: ProcTier, severe: Boolean): ProcTier {
        val order = listOf(ProcTier.P720, ProcTier.P540, ProcTier.P360)
        val idx = order.indexOf(current).coerceAtLeast(order.indexOf(floor).coerceAtLeast(0))
        return order[minOf(order.lastIndex, idx + if (severe) 2 else 1)]
    }

    private fun higher(current: ProcTier, ceiling: ProcTier): ProcTier {
        val order = listOf(ProcTier.P720, ProcTier.P540, ProcTier.P360)
        val idx = order.indexOf(current).coerceAtLeast(0)
        val ceilingIdx = order.indexOf(ceiling).coerceAtLeast(0)
        return order[maxOf(ceilingIdx, idx - 1)]
    }

    private fun pass() = Decision(Mode.PASSTHROUGH, ProcTier.P540)
}
