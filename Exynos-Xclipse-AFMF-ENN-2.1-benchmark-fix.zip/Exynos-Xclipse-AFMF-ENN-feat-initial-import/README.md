# Xclipse ENN-SS

Nội suy khung hình 30→60 FPS kiểu AFMF cho Android (MediaProjection → Vulkan compute → overlay), flow qua NPU Exynos (LiteRT/ENN) hoặc block-matching GPU.

Module: `core-capture` (MediaProjection + ring buffer) · `core-telemetry` (số liệu, governor) · `core-overlay` (cửa sổ video/HUD/menu) · `core-vulkan` (NDK: AHB import, shader, swapchain) · `core-enn` (backend suy luận) · `app`.

## Trạng thái thật
- **Chưa build, chưa chạy trên thiết bị.** Chỉ `pipeline.cpp` được kiểm cú pháp (header giả). Shader chưa qua glslang.
- Present dùng **Vulkan swapchain + vkCmdBlitImage**, không phải ASurfaceControl/fence AHB.
- Cần bật **dịch vụ Trợ năng** thủ công để cảm ứng xuyên qua ở độ mờ 100%.
- **Rủi ro chưa kiểm:** MediaProjection có thể chụp chính overlay (xem docs/TEST_PLAN.md §2).
- Model Refine chưa nối. Không kèm trọng số flow đã huấn luyện (xem models/README.md).
- Đường LiteRT không zero-copy; `EnnNativeBackend` là stub chờ SDK (docs/ENN_SDK_GUIDE.md).
- Ring buffer dùng mutex (không lock-free).

## Build
Push lên GitHub → Actions build APK debug. Hoặc Android Studio (NDK 27.0.12077973, CMake 3.22.1). Gradle wrapper jar chưa có: chạy `gradle wrapper` một lần.

## Thay đổi trong bản tối ưu tiếp theo
- Thêm công tắc **Governor thích ứng** vào menu nổi và màn Cài đặt. Trạng thái được lưu trong SharedPreferences.
- Governor dùng thời gian xử lý, tỷ lệ frame drop và trạng thái nhiệt để hạ tier khi có áp lực; chỉ tăng tier sau 180 quyết định ổn định (hysteresis).
- Tắt Governor sẽ khóa tier theo lựa chọn thủ công (AUTO = 540p). Chốt bảo vệ nhiệt CRITICAL vẫn hoạt động kể cả khi Governor tắt.
- Block matching có vòng tìm kiếm thô SAD 4x4, sau đó tinh chỉnh bằng SAD 8x8, giảm số phép so khớp đầy đủ ở giai đoạn tìm kiếm rộng.

### Giới hạn cần biết
Đây là tối ưu thuật toán ở tầng ứng dụng/shader, chưa phải tích hợp riêng cho Exynos 2600. Governor hiện chưa có bộ đếm GPU/NPU utilization theo API Samsung; chưa có ENN zero-copy, model flow được huấn luyện, hay queue async compute độc lập. Cần build bằng Android SDK/NDK và benchmark trên thiết bị thật trước khi kết luận hiệu năng.
